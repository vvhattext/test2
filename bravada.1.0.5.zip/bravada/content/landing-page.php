<?php
/**
 * This file handles landing page elements
 *
 * @package Bravada
 */

bravada_lpslider();
bravada_lpblocks();
bravada_lptext('one');
bravada_lpboxes(1);
bravada_lptext('two');
bravada_lpboxes(2);
bravada_lptext('three');
bravada_lpindex();
bravada_lptext('four');
		
// FIN